"""
Pywbem scriptlet to quit wbemcli
"""
print('Quit Scriplet. Quiting wbemcli')
quit()
