##############################################################################
#
# Copyright (C) Zenoss, Inc. 2019, all rights reserved.
#
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
#
##############################################################################


from pywbem import twisted_agent

class ExecQuery(twisted_agent.ExecQuery):
	# placeholder to maintain backward compatability
	pass
