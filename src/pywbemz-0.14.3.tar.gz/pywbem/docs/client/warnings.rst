
.. _`Warnings`:

Warnings
--------

.. automodule:: pywbem._warnings

.. autoclass:: pywbem.Warning
   :members:

   .. rubric:: Methods

   .. autoautosummary:: pywbem.Warning
      :methods:
      :nosignatures:

   .. rubric:: Attributes

   .. autoautosummary:: pywbem.Warning
      :attributes:

   .. rubric:: Details

.. autoclass:: pywbem.ToleratedServerIssueWarning
   :members:

   .. rubric:: Methods

   .. autoautosummary:: pywbem.ToleratedServerIssueWarning
      :methods:
      :nosignatures:

   .. rubric:: Attributes

   .. autoautosummary:: pywbem.ToleratedServerIssueWarning
      :attributes:

   .. rubric:: Details
