
.. _`WBEM server API`:

WBEM server API
===============

.. automodule:: pywbem._server

.. _`WBEMServer`:

WBEMServer
^^^^^^^^^^

.. autoclass:: pywbem.WBEMServer
   :members:

   .. rubric:: Methods

   .. autoautosummary:: pywbem.WBEMServer
      :methods:
      :nosignatures:

   .. rubric:: Attributes

   .. autoautosummary:: pywbem.WBEMServer
      :attributes:

   .. rubric:: Details
