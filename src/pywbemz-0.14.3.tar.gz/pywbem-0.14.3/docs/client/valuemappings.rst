
.. _`Mapping between ValueMap and Values qualifiers`:

Mapping between ValueMap and Values qualifiers
----------------------------------------------

.. automodule:: pywbem._valuemapping

.. autoclass:: pywbem.ValueMapping
   :members:

   .. rubric:: Methods

   .. autoautosummary:: pywbem.ValueMapping
      :methods:
      :nosignatures:

   .. rubric:: Attributes

   .. autoautosummary:: pywbem.ValueMapping
      :attributes:

   .. rubric:: Details
