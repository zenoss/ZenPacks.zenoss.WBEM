
.. _`CIM status codes`:

CIM status codes
----------------

.. automodule:: pywbem.cim_constants
   :members:
