
.. _`WBEM operation statistics`:

WBEM operation statistics
-------------------------

.. automodule:: pywbem._statistics

.. autoclass:: pywbem.Statistics
   :members:

   .. rubric:: Methods

   .. autoautosummary:: pywbem.Statistics
      :methods:
      :nosignatures:

   .. rubric:: Attributes

   .. autoautosummary:: pywbem.Statistics
      :attributes:

   .. rubric:: Details

.. autoclass:: pywbem.OperationStatistic
   :members:

   .. rubric:: Methods

   .. autoautosummary:: pywbem.OperationStatistic
      :methods:
      :nosignatures:

   .. rubric:: Attributes

   .. autoautosummary:: pywbem.OperationStatistic
      :attributes:

   .. rubric:: Details
