
.. _`WBEM operations`:

WBEM operations
---------------

.. automodule:: pywbem.cim_operations

WBEMConnection
^^^^^^^^^^^^^^

.. autoclass:: pywbem.WBEMConnection
   :members:

   .. rubric:: Methods

   .. autoautosummary:: pywbem.WBEMConnection
      :methods:
      :nosignatures:

   .. rubric:: Attributes

   .. autoautosummary:: pywbem.WBEMConnection
      :attributes:

   .. rubric:: Details
